-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               11.1.0-MariaDB-log - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table organisasi.tb_agenda
CREATE TABLE IF NOT EXISTS `tb_agenda` (
  `id_agenda` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` varchar(50) DEFAULT NULL,
  `waktu` varchar(50) DEFAULT NULL,
  `subjek` varchar(50) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  PRIMARY KEY (`id_agenda`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Data exporting was unselected.

-- Dumping structure for table organisasi.tb_anggota
CREATE TABLE IF NOT EXISTS `tb_anggota` (
  `id_anggota` int(11) NOT NULL AUTO_INCREMENT,
  `namalengkap` varchar(50) DEFAULT NULL,
  `ttl` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `level` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_anggota`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Data exporting was unselected.

-- Dumping structure for table organisasi.tb_barang
CREATE TABLE IF NOT EXISTS `tb_barang` (
  `no_barang` int(11) NOT NULL AUTO_INCREMENT,
  `kategori_barang` varchar(50) DEFAULT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `jumlah_barang` int(11) DEFAULT NULL,
  PRIMARY KEY (`no_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Data exporting was unselected.

-- Dumping structure for table organisasi.tb_kehadiran
CREATE TABLE IF NOT EXISTS `tb_kehadiran` (
  `id_anggota` int(11) DEFAULT NULL,
  `id_rapat` int(11) DEFAULT NULL,
  `namalengkap` varchar(50) DEFAULT NULL,
  KEY `FK_tb_kehadiran_tb_anggota` (`id_anggota`),
  KEY `FK_tb_kehadiran_tb_rapat` (`id_rapat`),
  CONSTRAINT `FK_tb_kehadiran_tb_anggota` FOREIGN KEY (`id_anggota`) REFERENCES `tb_anggota` (`id_anggota`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tb_kehadiran_tb_rapat` FOREIGN KEY (`id_rapat`) REFERENCES `tb_rapat` (`no_rapat`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Data exporting was unselected.

-- Dumping structure for table organisasi.tb_peminjaman
CREATE TABLE IF NOT EXISTS `tb_peminjaman` (
  `no_peminjaman` int(11) NOT NULL AUTO_INCREMENT,
  `no_barang` int(11) DEFAULT NULL,
  `jumlah_peminjaman` int(11) DEFAULT NULL,
  `identitas` varchar(50) DEFAULT NULL,
  `institusi` varchar(50) DEFAULT NULL,
  `bukti` text DEFAULT NULL,
  PRIMARY KEY (`no_peminjaman`),
  KEY `FK_tb_peminjaman_tb_barang` (`no_barang`),
  CONSTRAINT `FK_tb_peminjaman_tb_barang` FOREIGN KEY (`no_barang`) REFERENCES `tb_barang` (`no_barang`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Data exporting was unselected.

-- Dumping structure for table organisasi.tb_proker
CREATE TABLE IF NOT EXISTS `tb_proker` (
  `no_proker` int(11) NOT NULL AUTO_INCREMENT,
  `nama_proker` varchar(50) DEFAULT NULL,
  `deskripsi` varchar(50) DEFAULT NULL,
  `target` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_proker`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Data exporting was unselected.

-- Dumping structure for table organisasi.tb_rapat
CREATE TABLE IF NOT EXISTS `tb_rapat` (
  `no_rapat` int(11) NOT NULL AUTO_INCREMENT,
  `no_proker` int(11) NOT NULL,
  `subjek` varchar(50) NOT NULL DEFAULT '0',
  `tgl_rapat` varchar(50) NOT NULL DEFAULT '0',
  `undangan` text NOT NULL DEFAULT '0',
  `laporan` text NOT NULL DEFAULT '0',
  PRIMARY KEY (`no_rapat`),
  KEY `FK__tb_proker` (`no_proker`),
  CONSTRAINT `FK__tb_proker` FOREIGN KEY (`no_proker`) REFERENCES `tb_proker` (`no_proker`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Data exporting was unselected.

-- Dumping structure for table organisasi.tb_saran
CREATE TABLE IF NOT EXISTS `tb_saran` (
  `no_saran` int(11) NOT NULL AUTO_INCREMENT,
  `pengirim_saran` varchar(50) DEFAULT NULL,
  `subjek_saran` varchar(50) DEFAULT NULL,
  `isi_saran` text DEFAULT NULL,
  PRIMARY KEY (`no_saran`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Data exporting was unselected.

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
